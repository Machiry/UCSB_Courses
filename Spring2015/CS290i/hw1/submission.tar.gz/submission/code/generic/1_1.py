import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as pl

with open('/home/machiry/Desktop/wine.data','r') as f:
	l1 = []
	l2 = []
	feat = 3
	for i in f:
		i = i.strip()
		if i.split(',')[0] is '1':
			x = i.split(',')[feat]
			if x is not '?':
				x = float(i.split(',')[feat])
				l1.append(x)
		else:
			x = i.split(',')[feat]
			if x is not '?':
				x = float(i.split(',')[feat])
				l2.append(x)
	
	l1.sort()
	l2.sort()

	fit1 = stats.norm.pdf(l1, np.mean(l1), np.std(l1)) 
	pl.plot(l1,fit1)
	#pl.hist(l1,normed=True)
	fit2 = stats.norm.pdf(l2, np.mean(l2), np.std(l2))
	pl.plot(l2,fit2)
	#pl.hist(l2,normed=True)
	pl.show()                  
